CODESWIFT - DESKTOP MARKDOWN EDITOR & SNIPPET MANAGER
=====================================================

Thank you for your purchase!

INCLUDED BUILDS:
- macOS (Universal Binary - Intel + Apple Silicon)
- Windows (x64 installer)
- Linux (AppImage)

FEATURES:
- Vim keybindings & code folding
- 50+ Language syntax highlighting
- Local-first security with encrypted backup
- Cloud sync (optional, end-to-end encrypted)
- Snippet library with tagging and search
- Hotkey expansions for frequently used text
- Split-pane view (editor + preview)
- Export to PDF, HTML, and DOCX

ACTIVATION:
Your license key is included in LICENSE-KEY.txt
Enter it on first launch to activate.

LICENSE: Single device license.

(c) 2026 DigitalHub. All rights reserved.