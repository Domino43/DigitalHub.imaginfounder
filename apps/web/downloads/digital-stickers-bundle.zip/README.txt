WHIMSICAL DIGITAL STICKERS BUNDLE
===================================

Thank you for your purchase!

This package contains 500+ hand-drawn digital stickers in PNG format
with transparent backgrounds.

CATEGORIES:
- Productivity icons (100+)
- Cute animals (50+)
- Plants & nature (80+)
- Weather elements (30+)
- Holiday & seasonal (60+)
- Decorative borders (40+)
- Functional tabs (50+)
- Emoji-style faces (90+)

FORMAT: PNG, 300 DPI, transparent background
COMPATIBILITY: GoodNotes, Notability, Xodo, Flexcil

LICENSE: Single user license. Not for redistribution.

(c) 2026 DigitalHub. All rights reserved.