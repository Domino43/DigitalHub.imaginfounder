CANDID WARM TONE CREATOR WORKSPACE STOCK PHOTO PACK
====================================================

Thank you for your purchase!

This package contains 25 high-resolution stock photographs.

PHOTO CATEGORIES:
- Cozy desk flat lays (8 photos)
- Laptop + coffee scenes (6 photos)
- Plant + workspace (5 photos)
- iPad + notebook (3 photos)
- Creative process shots (3 photos)

SPECIFICATIONS:
- Resolution: 6000 x 4000 px
- DPI: 300
- Format: JPEG
- Color profile: sRGB
- Warm tone grading applied

ALSO INCLUDED:
- 5 LUT profile files (.cube) for applying the warm tone
  to your own photos in Lightroom, Premiere, or DaVinci Resolve
- Commercial licensing agreement (PDF)

LICENSE: Lifetime royalty-free commercial license.
Use across websites, printable goods, ads, and templates.
No attribution required.

(c) 2026 DigitalHub. All rights reserved.