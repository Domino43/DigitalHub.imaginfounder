ArtDisplay website template
1. Unzip this folder.
2. Open index.html in a browser.
3. Replace the placeholder copy and add your images into /assets.
4. Upload the whole folder to Netlify, Cloudflare Pages, or GitHub Pages.

Personal / one-client use. Do not resell the template.
