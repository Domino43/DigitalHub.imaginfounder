ARTDISPLAY - MINIMALIST PORTFOLIO GALLERY APP
==============================================

Thank you for your purchase!

FEATURES:
- Responsive masonry layout grid
- Built-in lightbox viewer with keyboard navigation
- Dark/light theme toggle
- Image upload component with drag-and-drop
- Category filtering with smooth animations
- SEO-optimized with meta tags
- Docker deployment config included

REQUIREMENTS: Node.js 18+, npm

QUICK START:
1. npm install
2. npm run dev
3. Open http://localhost:3000

LICENSE: Single project license. Not for redistribution.

(c) 2026 DigitalHub. All rights reserved.