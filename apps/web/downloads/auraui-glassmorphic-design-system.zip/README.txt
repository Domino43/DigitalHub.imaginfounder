AURAUI - GLASSMORPHIC DESIGN SYSTEM & UI KIT
==============================================

Thank you for your purchase!

WHAT IS INCLUDED:
- 150+ Glassmorphic UI components
- 12 pre-built dashboard layouts
- Design tokens (colors, typography, spacing, shadows)
- Icon library (200+ icons)
- Dark and light mode variants
- Auto-layout components for responsive design
- Interactive prototype examples
- Documentation with usage guidelines

HOW TO USE:
1. Open Figma (free account works)
2. Go to File > Import and select the .fig file
3. All components will appear in your Assets panel
4. Drag and drop components into your designs

REQUIREMENTS: Figma account (free or paid)

LICENSE: Single designer license. Not for team sharing
without additional seats. Contact for team pricing.

(c) 2026 DigitalHub. All rights reserved.