Aura UI website template
Open index.html in a browser. Edit the copy in each HTML file.
Personal / client use. Do not resell the template itself.
