MODERN MINIMALIST CREATOR WEBSITE TEMPLATE
=============================================

Thank you for your purchase!

This package contains a complete React + Tailwind CSS website template.

WHAT IS INCLUDED:
- Full source code (React + Vite + Tailwind)
- 5 pre-built page layouts
- Responsive design (mobile, tablet, desktop)
- Dark mode support
- Contact form component
- Blog template with MDX support
- Portfolio grid with filtering
- Documentation PDF

DEVELOPER LICENSE: Use on 1 personal website + up to 3 commercial
client projects. No redistribution or reselling of the code.

(c) 2026 DigitalHub. All rights reserved.